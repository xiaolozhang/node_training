#!/usr/bin/env node

const workshopper = require('workshopper')
    , path        = require('path')
    , submit      = require('./submit')
    , menu        = require('./exercises/menu')

    , name        = 'nodeready'
    , title       = 'NodeReady - \x1b[3mby The Node Firm\x1b[23m'
    , subtitle    = '\x1b[23mSelect an exercise and hit \x1b[3mEnter\x1b[23m to begin'


function fpath (f) {
  return path.join(__dirname, f)
}


workshopper({
    name        : name
  , title       : title
  , subtitle    : subtitle
  , exerciseDir : fpath('./exercises/')
  , appDir      : __dirname
  , menuItems   : [ {
        name    : 'submit solutions'
      , handler : submit
    } ]
})