module.exports = require('workshopper-exercise')()
