// get a random integer between 1 and 6 (inclusive)
module.exports = function() {
  return Math.floor(Math.random() * 6) + 1;
}
