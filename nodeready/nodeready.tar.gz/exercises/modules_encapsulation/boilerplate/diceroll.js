// get a random integer between 1 and 6 (inclusive)
module.exports = Math.floor((Math.random() * 6) + 1)
