module.exports = function foo(x) {
  return x * Math.PI;
}
