var pi = require('./pi');
var arg = Number(process.argv[2]);
var result = pi(arg);

console.log(result);
