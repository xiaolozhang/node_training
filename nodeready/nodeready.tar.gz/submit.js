const os         = require('os')
    , fs         = require('fs')
    , path       = require('path')
    , fstream    = require('fstream')
    , tar        = require('tar')
    , zlib       = require('zlib')
    , hyperquest = require('hyperquest')
    , bl         = require('bl')
    , read       = require('read')
    , once       = require('once')

const postHost      = 'nodeready-submit.require.io'
    , postUrlPrefix = 'http://' + postHost + '/nodeready/submit/'


// fetch user details from github given a username
function fetchUser (username, callback) {
  hyperquest(
      'https://api.github.com/users/' + username
    , { headers: { 'user-agent': 'Node.js' } }
  ).pipe(bl(function (err, data) {
    if (err)
      return callback(err)

    var _data = JSON.parse(data)
    callback(null, _data)
  }))
}


// get github username from user from stdin
function getUser (callback) {
  read({ prompt: 'Enter your GitHub username: ' }, function (err, username) {
    if (err)
      return callback(err)

    fetchUser(username, function (err, data) {
      if (err)
        return callback(err)

      if (data.message) {
        console.error('Error looking up [' + username + ']: ' + data.message)
        return getUser(callback)
      }

      console.log('Is this you?')
      console.log('\tUsername: %s', data.login)
      console.log('\tName:     %s', data.name)
      if (data.company)
        console.log('\tCompany:  %s', data.company)
      if (data.blog)
        console.log('\tBlog:     %s', data.blog)
      if (data.email)
        console.log('\tEmail:    %s', data.email)

      ;(function yorn () {
        read({ prompt: 'Yes or no [y/n]: ' }, function (err, yn) {
          if (err)
            return callback(err)

          yn = yn.toLowerCase().charAt(0)
          if (yn == 'y')
            return callback(null, data.login)

          yorn()
        })
      })()
    })
  })
}


// given a .tgz, upload it to TNF
function upload (username, outFile) {
  var error = once(function () {
        console.log('Failed to upload submission')
        console.log('Please send an email to nodeready@thenodefirm.com and attach the file located at:')
        console.log('\t', outFile)
      })

    , req = hyperquest.post(postUrlPrefix + username, {
        headers: {
            host: postHost
            // fake it to make the hapi proxy happy:
          , 'content-type': 'application/x-www-form-urlencoded'
        }
      })

  fs.createReadStream(outFile)
    .pipe(req)
    .on('error', error)

  req.pipe(bl(function (err, data) {
    if (err)
      return error()

    if (data.toString() != 'success')
      return error()

    console.log('Successfully uploaded submission')
  }))
}


// pack up the submission and send it to TNF
function submit (workshopper) {
  getUser(function (err, username) {
    if (err)
      throw err

    var dataDir = path.join(workshopper.dataDir, 'submissions')
      , outFile = path.join(os.tmpDir(), 'nodeready_' + username + '_' + process.pid + '.tgz')

    fstream.Reader({ path: dataDir, type: 'Directory', isDirectory: true })
      .pipe(tar.Pack())
      .pipe(zlib.Gzip())
      .pipe(fs.createWriteStream(outFile))
      .on('finish', function () {
        console.log('\nUploading submission...')
        upload(username, outFile)
      })
  })
}


module.exports = submit
